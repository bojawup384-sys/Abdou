import { sql } from "drizzle-orm";
import { db } from "./index";

/**
 * يُنشئ الجداول الناقصة تلقائيًا (آمن للتكرار).
 * الجداول بادئتها adcraft_ حتى لا تتعارض مع جداول قديمة
 * (users / subscriptions / generations ...) في نفس قاعدة Neon.
 */
let ready: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!ready) {
    ready = run().catch((e) => {
      ready = null; // أعد المحاولة في الطلب القادم
      throw e;
    });
  }
  return ready;
}

async function run() {
  // gen_random_uuid() مدمجة في Postgres 13+ (Neon) — لا حاجة لإضافة pgcrypto
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS adcraft_users (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      uid text UNIQUE,
      email text,
      display_name text,
      device_id text UNIQUE,
      credits integer NOT NULL DEFAULT 5,
      credits_day text NOT NULL DEFAULT '1970-01-01',
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    )`);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS adcraft_ads (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid NOT NULL REFERENCES adcraft_users(id) ON DELETE CASCADE,
      platform text NOT NULL,
      tone text NOT NULL,
      goal text NOT NULL,
      product text NOT NULL,
      audience text,
      pack jsonb NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    )`);
  await db.execute(
    sql`CREATE INDEX IF NOT EXISTS adcraft_ads_user_id_idx ON adcraft_ads (user_id)`
  );
  await db.execute(
    sql`CREATE INDEX IF NOT EXISTS adcraft_ads_created_at_idx ON adcraft_ads (created_at)`
  );
}
