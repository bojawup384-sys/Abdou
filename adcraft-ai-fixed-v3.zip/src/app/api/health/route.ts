import { sql } from "drizzle-orm";

import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { envStatus } from "@/lib/env";

export const dynamic = "force-dynamic";

function reason(e: unknown): string {
  const parts: string[] = [];
  let cur: unknown = e;
  for (let i = 0; i < 3 && cur; i++) {
    if (cur instanceof Error) parts.push(cur.message);
    cur = (cur as { cause?: unknown }).cause;
  }
  return parts.join(" | ").replace(/postgres(ql)?:\/\/\S+/gi, "[url]").slice(0, 300);
}

/** GET /api/health — يعرض حالة الإعدادات والقاعدة (بدون أي أسرار) */
export async function GET() {
  const env = envStatus();
  const out: Record<string, unknown> = { ...env };

  try {
    await db.execute(sql`select 1`);
    out.dbConnect = true;
  } catch (e) {
    out.dbConnect = false;
    out.dbConnectError = reason(e);
  }

  if (out.dbConnect) {
    try {
      await ensureSchema();
      out.schema = true;
    } catch (e) {
      out.schema = false;
      out.schemaError = reason(e);
    }
  }

  const ok = out.dbConnect === true && out.schema === true && env.geminiKey;
  return Response.json({ ok, ...out }, { status: ok ? 200 : 500 });
}
