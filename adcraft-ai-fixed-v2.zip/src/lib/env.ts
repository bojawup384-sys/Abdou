/**
 * قراءة متغيرات البيئة بمرونة (خادم فقط)
 * ------------------------------------------------------------------
 * يقرأ مفتاح Gemini من أي اسم من الأسماء التالية بالترتيب:
 *   GEMINI_API_KEY  ثم  NEXT_PUBLIC_GEMINI_API_KEY
 * ويتجاهل القيم الفارغة أو المسافات، ويزيل علامات الاقتباس
 * التي تُلصق بالخطأ مع المفتاح في لوحة Vercel.
 *
 * ملاحظة: يجب كتابة process.env.NAME حرفيًا (بدون أقواس مربعة)
 * كي يستبدلها Next.js وقت البناء.
 */

function clean(value: string | undefined): string | null {
  if (!value) return null;
  const v = value.trim().replace(/^["']+|["']+$/g, "").trim();
  return v.length > 0 ? v : null;
}

export function getGeminiApiKey(): string | null {
  return (
    clean(process.env.GEMINI_API_KEY) ??
    clean(process.env.NEXT_PUBLIC_GEMINI_API_KEY)
  );
}

/** حالة المتغيرات المهمة (قيم منطقية فقط — لا تُسرّب أي سر) */
export function envStatus() {
  return {
    geminiKey: getGeminiApiKey() !== null,
    databaseUrl: clean(process.env.DATABASE_URL) !== null,
  };
}

export const GEMINI_KEY_MISSING_MESSAGE =
  "مفتاح Gemini مفقود: أضف GEMINI_API_KEY في Vercel ← Settings ← Environment Variables (لكل البيئات)، ثم أعد النشر (Redeploy). لم يُخصم أي رصيد.";
