import { db } from "@/db";
import { envStatus } from "@/lib/env";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** GET /api/health — يعرض حالة الإعدادات (true/false فقط، بدون أي أسرار) */
export async function GET() {
  const env = envStatus();
  let dbOk = false;
  let dbError: string | undefined;
  try {
    await db.execute(sql`select 1`);
    dbOk = true;
  } catch (e) {
    dbError = e instanceof Error ? e.message.slice(0, 120) : "unknown";
  }
  const ok = dbOk && env.geminiKey;
  return Response.json(
    { ok, db: dbOk, ...env, ...(dbError ? { dbError } : {}) },
    { status: ok ? 200 : 500 }
  );
}
