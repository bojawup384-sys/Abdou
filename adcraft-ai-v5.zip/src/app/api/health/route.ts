import { sql } from "drizzle-orm";

import { db } from "@/db";
import { ensureSchema } from "@/db/ensure";
import { describeError } from "@/lib/dbError";
import { envStatus } from "@/lib/env";

export const dynamic = "force-dynamic";

/** GET /api/health — يعرض حالة الإعدادات والقاعدة (بدون أي أسرار) */
export async function GET() {
  const env = envStatus();
  const out: Record<string, unknown> = { ...env };

  try {
    await db.execute(sql`select 1`);
    out.dbConnect = true;
  } catch (e) {
    out.dbConnect = false;
    out.dbConnectError = describeError(e);
  }

  if (out.dbConnect) {
    try {
      await ensureSchema();
      out.schema = true;
    } catch (e) {
      out.schema = false;
      out.schemaError = describeError(e);
    }
  }

  const ok = out.dbConnect === true && out.schema === true && env.geminiKey;
  return Response.json({ ok, ...out }, { status: ok ? 200 : 500 });
}
