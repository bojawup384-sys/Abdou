/**
 * يحوّل أي خطأ إلى سطر قصير وآمن للعرض (السبب الجذري أولًا):
 * - يحذف روابط الاتصال (postgres://...) وقيم params (قد تحتوي بريدك)
 * - لا يحتوي أي مفتاح سري
 */
export function describeError(e: unknown): string {
  const parts: string[] = [];
  let cur: unknown = e;
  for (let i = 0; i < 4 && cur; i++) {
    if (cur instanceof Error) {
      const code = (cur as { code?: unknown }).code;
      parts.push(`${cur.name}${code ? `(${String(code)})` : ""}: ${cur.message}`);
    } else {
      parts.push(String(cur));
    }
    cur = (cur as { cause?: unknown }).cause;
  }
  return parts
    .reverse()
    .join(" <- ")
    .replace(/postgres(ql)?:\/\/\S+/gi, "[url]")
    .replace(/params:[^<]*/gi, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 220);
}
