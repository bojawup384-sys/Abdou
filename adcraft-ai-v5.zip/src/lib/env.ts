/**
 * قراءة متغيرات البيئة بمرونة (خادم فقط)
 * يتجاهل الفراغات وعلامات الاقتباس، ويقبل أسماء بديلة شائعة.
 */
function clean(value: string | undefined): string | null {
  if (!value) return null;
  const v = value.trim().replace(/^[\"']+|[\"']+$/g, "").trim();
  return v.length > 0 ? v : null;
}

export function getGeminiApiKey(): string | null {
  return (
    clean(process.env.GEMINI_API_KEY) ??
    clean(process.env.GOOGLE_API_KEY) ??
    clean(process.env.GOOGLE_GENERATIVE_AI_API_KEY) ??
    clean(process.env.NEXT_PUBLIC_GEMINI_API_KEY)
  );
}

/**
 * رابط Neon: يقبل DATABASE_URL أو POSTGRES_URL (تكامل Vercel+Neon)،
 * ويصلح الأخطاء الشائعة عند النسخ من لوحة Neon:
 *   psql 'postgresql://...'   أو   "postgresql://..."   أو   channel_binding=require
 */
export function getDatabaseUrl(): string | null {
  const raw =
    clean(process.env.DATABASE_URL) ??
    clean(process.env.POSTGRES_URL) ??
    clean(process.env.DATABASE_URL_UNPOOLED) ??
    clean(process.env.POSTGRES_URL_NON_POOLING);
  if (!raw) return null;
  const m = /postgres(?:ql)?:\/\/[^\s'"]+/i.exec(raw);
  if (!m) return null;
  return m[0].replace(/[&?]channel_binding=[^&]*/i, "").replace(/\?$/, "");
}

export function envStatus() {
  return {
    geminiKey: getGeminiApiKey() !== null,
    databaseUrl: getDatabaseUrl() !== null,
  };
}

/** المحرك المحلي يعمل احتياطيًا افتراضيًا إلا إذا ضُبط ALLOW_LOCAL_FALLBACK=false */
export function localFallbackAllowed(): boolean {
  return (process.env.ALLOW_LOCAL_FALLBACK ?? "").trim().toLowerCase() !== "false";
}

export const GEMINI_KEY_MISSING_MESSAGE =
  "مفتاح Gemini مفقود: أضف GEMINI_API_KEY في Vercel ← Settings ← Environment Variables ثم أعد النشر (Redeploy).";
