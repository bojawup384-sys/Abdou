import { neon } from "@neondatabase/serverless";
import { drizzle, type NeonHttpDatabase } from "drizzle-orm/neon-http";

import { getDatabaseUrl } from "../lib/env";

/** اتصال Neon كسول — لا يُنشأ إلا عند أول استعلام فعلي */
let _db: NeonHttpDatabase | null = null;

function getDb(): NeonHttpDatabase {
  if (_db) return _db;
  const url = getDatabaseUrl();
  if (!url) {
    throw new Error(
      "DATABASE_URL غير مضبوط — أضفه في Vercel > Settings > Environment Variables"
    );
  }
  _db = drizzle(neon(url));
  return _db;
}

export const db = new Proxy({} as NeonHttpDatabase, {
  get(_target, prop) {
    const real = getDb();
    const value = Reflect.get(real, prop, real);
    return typeof value === "function" ? value.bind(real) : value;
  },
});
